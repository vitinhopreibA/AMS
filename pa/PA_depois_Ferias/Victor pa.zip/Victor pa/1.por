programa
{
	funcao inicio()
	{
		// Variaveis simples
		inteiro numero
		inteiro soma = 0
		inteiro quant = 0
		inteiro maior = 0
		inteiro menor = 0
		inteiro soma_pares = 0
		inteiro quant_pares = 0
		inteiro quant_impares = 0
		
		real media = 0.0
		real media_pares = 0.0
		real porc_impares = 0.0

		escreva("Digite um numero positivo (ou 0 para sair): ")
		leia(numero)

		
		enquanto (numero > 0)
		{

			se (quant == 0)
			{
				maior = numero
				menor = numero
			}

			se (numero > maior) 
			{ 
				maior = numero 
			}

			se (numero < menor) 
			{ 
				menor = numero 
			}

			quant = quant + 1
			soma = soma + numero

			se (numero % 2 == 0)
			{
				soma_pares = soma_pares + numero
				quant_pares = quant_pares + 1
			}
			se (numero % 2 != 0)
			{
				quant_impares = quant_impares + 1
			}

			escreva("Digite outro numero positivo (ou 0 para sair): ")
			leia(numero)
		}

		se (quant > 0)
		{
	
			media = (soma * 1.0) / quant
			porc_impares = ((quant_impares * 1.0) / quant) * 100

			escreva("\n--- RESULTADOS ---\n")
			escreva("Soma dos numeros: ", soma, "\n")
			escreva("Quantidade de numeros: ", quant, "\n")
			escreva("Media dos numeros: ", media, "\n")
			escreva("Maior numero: ", maior, "\n")
			escreva("Menor numero: ", menor, "\n")
			
			se (quant_pares > 0) 
			{
				media_pares = (soma_pares * 1.0) / quant_pares
				escreva("Media dos numeros pares: ", media_pares, "\n")
			} 
			se (quant_pares == 0) 
			{
				escreva("Media dos numeros pares: Nenhum par foi digitado\n")
			}
			
			escreva("Porcentagem de impares: ", porc_impares, "%\n")
		}
		se (quant == 0)
		{
			escreva("\nVoce nao digitou nenhum numero positivo.\n")
		}
	}
}
