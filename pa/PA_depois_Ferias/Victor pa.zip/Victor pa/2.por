programa
{
	inclua biblioteca Tipos --> t
	
	funcao inicio()
	{
		inteiro idade
		inteiro total_idades = 0
		inteiro soma_idades = 0
		inteiro maiores_21 = 0
		real media = 0.0
		caracter resposta = 'S'

		enquanto (resposta == 'S' ou resposta == 's')
		{
			escreva("Digite a idade da pessoa: ")
			leia(idade)

			total_idades = total_idades + 1

			se (idade >= 21)
			{
				maiores_21 = maiores_21 + 1
			}
			escreva("Deseja continuar digitando dados? [S/N]: ")
			leia(resposta)
			escreva("\n") 
		}

		se (total_idades > 0)
		{
			media = t.inteiro_para_real(soma_idades) / total_idades
		}
		escreva("--------------------------------------------------\n")
		escreva("a) Quantas idades foram digitadas: ", total_idades, "\n")
		escreva("b) Qual é a média entre as idades digitadas: ", media, "\n")
		escreva("c) Quantas pessoas tem 21 anos ou mais: ", maiores_21, "\n")
		escreva("--------------------------------------------------\n")
	}
}
