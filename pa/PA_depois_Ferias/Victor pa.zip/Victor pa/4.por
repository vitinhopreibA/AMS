programa
{
	funcao inicio()
	{
		inteiro numero, fatorial = 1

		escreva("Digite um número para calcular o fatorial: ")
		leia(numero)

		
		se (numero < 0)
		{
			escreva("Erro: Não existe fatorial de número negativo.\n")
		}
		senao
		{
			escreva(numero, "! = ")

			se (numero == 0)
			{
				escreva("1")
			}
			senao
			{
	
				para (inteiro i = numero; i >= 1; i--)
				{
					fatorial = fatorial * i
					
					escreva(i)

					se (i > 1)
					{
						escreva(" x ")
					}
					senao
					{
						escreva(" = ")
					}
				}
				escreva(fatorial)
			}
			escreva("\n")
		}
	}
}
